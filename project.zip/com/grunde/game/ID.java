package com.grunde.game;

public enum ID {

    Player(),
    BasicEnemy(),
    Trail();

}
